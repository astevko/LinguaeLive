/**
 * 
 */
package ca.jhosek.main.client;

import com.google.gwt.i18n.client.Constants;

import ca.jhosek.main.client.activity.mainregion.InstructorYourCourseActivity;
import ca.jhosek.main.client.ui.anon.ContactUsViewImpl;
import ca.jhosek.main.client.ui.anon.CourseBrowseViewImpl;
import ca.jhosek.main.client.ui.anon.LostAccountViewImpl;
import ca.jhosek.main.client.ui.priv.MyCoursesViewImpl;
import ca.jhosek.main.client.ui.priv.MyProfileViewImpl;
import ca.jhosek.main.client.ui.priv.admin.AdminUserViewerImpl;
import ca.jhosek.main.client.ui.priv.admin.QueryCoursesViewImpl;
import ca.jhosek.main.client.ui.priv.admin.QueryUsersViewImpl;
import ca.jhosek.main.client.ui.priv.instructor.InstructorCourseLinkViewImpl;
import ca.jhosek.main.client.ui.priv.instructor.InstructorHomeViewImpl;
import ca.jhosek.main.client.ui.priv.instructor.InstructorMemberViewImpl;
import ca.jhosek.main.client.ui.priv.instructor.InstructorYourCourseViewImpl;
import ca.jhosek.main.client.ui.priv.student.PartnerInviteDialog;
import ca.jhosek.main.client.ui.priv.student.PartnerInviteViewImpl;
import ca.jhosek.main.client.ui.priv.student.SessionControlViewImpl;
import ca.jhosek.main.client.ui.priv.student.StudentCourseDetailReportViewImpl;
import ca.jhosek.main.client.ui.priv.student.StudentHomeViewImpl;
import ca.jhosek.main.client.ui.priv.student.StudentYourCourseViewImpl;

/**
 * @author andy
 * @see Constants
 */
public interface LLConstants extends Constants {

	String bothPasswordsMustMatch();

	String pleaseAcceptTheTermsOfService();

	/**
	 * @see LostAccountViewImpl
	 * @return
	 */
	String pleaseEnterAValidEmailAddress();

	/**
	 * @return "dd MMM yyyy"
	 * @see CourseBrowseViewImpl
	 */
	String mdyDateFormatterPattern();

	/**
	 * @return "Name"
	 * @see CourseBrowseViewImpl
	 * @see MyCoursesViewImpl
	 * @see QueryCoursesViewImpl
	 */
	String name();

	/**
	 * @return
	 * @see CourseBrowseViewImpl
	 * @see MyCoursesViewImpl
	 */
	String startDate();

	/**
	 * @return
	 * @see CourseBrowseViewImpl
	 */
	String targetLanguage();

	/**
	 * @return
	 * @see CourseBrowseViewImpl
	 */
	String expertLanguage();

	/**
	 * @return
	 * @see CourseBrowseViewImpl
	 * @see QueryCoursesViewImpl
	 */
	String school();

	/**
	 * @return
	 * @see CourseBrowseViewImpl
	 */
	String location();

	/**
	 * @see ContactUsViewImpl
	 */
	String contactUsReason1();

	/**
	 * @see ContactUsViewImpl
	 */
	String contactUsReason2();

	/**
	 * @see ContactUsViewImpl
	 */
	String contactUsReason3();

	/**
	 * @see ContactUsViewImpl
	 */
	String contactUsReason4();

	/**
	 * @see ContactUsViewImpl
	 */
	String contactUsReason5();

	/**
	 * @see ContactUsViewImpl
	 */
	String contactUsReason6();

	/**
	 * @see ContactUsViewImpl
	 */
	String contactUsReason();

	/**
	 * @see MyProfileViewImpl
	 */
	String loadingContactInfo();

	/**
	 * @see MyCoursesViewImpl
	 */
	String viewEditButton();

	/**
	 * @see MyCoursesViewImpl
	 */
	String endDate();

	/**
	 * @see MyCoursesViewImpl
	 */
	String noCoursesFound();

	/**
	 * @see QueryUsersViewImpl
	 */
	String noUsersFound();

	/**
	 * @see QueryUsersViewImpl
	 */
	String selectAUser();

	/**
	 * @see QueryUsersViewImpl
	 */
	String instructor();

	/**
	 * @see QueryUsersViewImpl
	 */
	String emailAddress();

	/**
	 * @see QueryUsersViewImpl
	 */
	String estMembership();

	/**
	 * @see QueryUsersViewImpl
	 */
	String inviteCode();

	/**
	 * @see AdminUserViewerImpl
	 */
	String noContactInfoFound();

	String loadingLinkedCourses();

	/**
	 * @return InstructorYourCourseViewImpl
	 */
	String loadingStudents();

	/**
	 * @see InstructorYourCourseActivity
	 */
	String loadingUnlinkedCourses();

	String noLinkedCoursesFound();
	
	String noStudentsEnrolledWithinThisCourse();

	String noPastComplementaryCoursesFound();

	/**
	 * @see InstructorYourCourseViewImpl
	 */
	String noCurrentComplementaryCoursesFound();

	/**
	 * @see InstructorYourCourseViewImpl
	 */
	String showConcurrentCourses();

	/**
	 * @see InstructorYourCourseViewImpl
	 */
	String showPastCourses();

	/**
	 * @see InstructorYourCourseViewImpl
	 */
	String unlinkedCoursesBlurb();
	
	/**
	 * @see InstructorYourCourseViewImpl
	 */
	String noPastCoursesFound();

	/**
	 * @see InstructorCourseLinkViewImpl
	 */
	String hiddenUntilConfirmed();

	/**
	 * @see InstructorHomeViewImpl
	 */
	String noPendingLinkedCoursesFound();

	/**
	 * @see InstructorHomeViewImpl
	 */
	String noOpenLinkedCoursesFound();

	/**
	 * @see InstructorHomeViewImpl
	 */
	String loadingPendingLinkedCourses();

	/**
	 * @see InstructorHomeViewImpl
	 */
	String loadingOpenLinkedCourses();

	/**
	 * @see InstructorMemberViewImpl
	 */
	String noScheduleAvailabilityInformationRecorded();

	/**
	 * @see InstructorMemberViewImpl
	 * @see StudentYourCourseViewImpl
	 */
	String hour();

	/**
	 * @see PartnerInviteDialog
	 */
	String dateTimeDateFormatterPattern();

	/**
	 * @return dd MMMM yyyy HH:mm zzz
	 */
	String mdyhmzDateFormatterPattern();	
	/**
	 * @see StudentCourseDetailReportViewImpl
	 */
	String sessionNotYetStarted();

	/**
	 * @see StudentCourseDetailReportViewImpl
	 */
	String noSessionsFound();

	/**
	 * @see SessionControlViewImpl
	 */
	String noNotesHaveBeenEnteredForThisSession();

	/**
	 * @see SessionControlViewImpl
	 */
	String sessionCancelled();

	/**
	 * @see SessionControlViewImpl
	 * @see StudentHomeViewImpl
	 */
	String sessionInProgress();

	/**
	 * @see SessionControlViewImpl
	 */
	String sessionCompleted();

	/**
	 * @see SessionControlViewImpl
	 * @see StudentHomeViewImpl
	 * 
	 */
	String sessionNotStarted();

	/**
	 * @see SessionControlViewImpl
	 */
	String stopTiming();

	/**
	 * @see SessionControlViewImpl
	 * @see PartnerInviteViewImpl
	 */
	String session();

	/**
	 * @see SessionControlViewImpl
	 */
	String switchToTiming();

	/**
	 * @see PartnerInviteViewImpl
	 */
	String startTiming();

	/**
	 * @see StudentHomeViewImpl
	 */
	String noPendingSessionInvitesFound();

	/**
	 * @see StudentHomeViewImpl
	 */
	String noUnfinishedSessionsFound();

	/**
	 * @see StudentHomeViewImpl
	 */
	String inviteFor();

	/**
	 * @see StudentHomeViewImpl
	 */
	String invite();

	/**
	 * @see StudentHomeViewImpl
	 */
	String from();

	/**
	 * @see StudentHomeViewImpl
	 */
	String to();

	/**
	 * @see StudentHomeViewImpl
	 */
	String invitePending();

	/**
	 * @see StudentHomeViewImpl
	 */
	String inviteAccepted();

	/**
	 * @see StudentHomeViewImpl
	 */
	String inviteRejected();

	/**
	 * @see StudentHomeViewImpl
	 */
	String minutes();

	/**
	 * @see StudentHomeViewImpl
	 */
	String loadingPartnerInvites();

	/**
	 * @see StudentHomeViewImpl
	 */
	String loadingSessions();	

	/**
	 * @see StudentYourCourseViewImpl
	 */
	String noOtherStudentsHaveComplementaryAvailability();

	/**
	 * @see StudentYourCourseViewImpl
	 */
	String noSessionInvitesFoundForThisCourse();

	/**
	 * @see StudentYourCourseViewImpl
	 */
	String pleaseChangeYourAvailability();

	/**
	 * @see StudentYourCourseViewImpl
	 */
	String loadingAvailabilitySchedule();
}
